## 2015-08-21 - Release 0.8.1

Use docker for acceptance tests

## 2015-06-29 - Release 0.8.0

allow to specify a user for the archive extraction and the archive download

## 2015-06-26 - Release 0.7.5

Fix strict_variables activation with rspec-puppet 2.2

## 2015-05-28 - Release 0.7.4

Add beaker_spec_helper to Gemfile

## 2015-05-26 - Release 0.7.3

Use random application order in nodeset

## 2015-05-26 - Release 0.7.2

add utopic & vivid nodesets

## 2015-05-25 - Release 0.7.1

Don't allow failure on Puppet 4

## 2015-05-18 - Release 0.7.0

Support tar.xz format

## 2015-05-13 - Release 0.6.2

Add puppet-lint-file_source_rights-check gem

## 2015-05-12 - Release 0.6.1

Don't pin beaker

## 2015-05-12 - Release 0.6.0

Support the purging of target directories

## 2015-04-27 - Release 0.5.3

Add nodeset ubuntu-12.04-x86_64-openstack

## 2015-04-17 - Release 0.5.2

Add beaker nodesets

## 2015-04-03 - Release 0.5.1

Confine rspec pinning to ruby 1.8
Fix when not using digest_url

## 2015-03-24 - Release 0.5.0

Add a proxy_server parameter

## 2015-03-24 - Release 0.4.1

Add unit tests

## 2015-03-06 - Release 0.4.0

Add --strip-components support

## 2015-01-07 - Release 0.3.6

Fix unquoted strings in cases

## 2015-01-05 - Release 0.3.5

Simplify bundler cache in Travis CI
Fix license name in metadata.json

## 2014-11-18 Release 0.3.2

Linting metadata

## 2014-11-04 Release 0.3.1

Fix missing comma

## 2014-11-04 Release 0.3.0

Add path to execs

## 2014-11-04 Release 0.2.1

Drop Puppet 2.7 support

## 2014-10-20 Release 0.2.0

Setup automatic Forge releases

## 2014-09-24 Release 0.1.3

Bug fix

## 2014-09-23 Release 0.1.2

Quote url to get the data from

## 2014-09-05 Release 0.1.1

Allow disabling of no-checksum notices in puppetmaster logs

## 2014-07-02 Release 0.1.0

Make curl silent, #21
Add documentation
Fix strict variables
